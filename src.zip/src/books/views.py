import datetime
from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.utils import timezone
from django.views import generic
from .models import Book



class AllAuthorsView(generic.TemplateView):
    template_name = 'book_author.html'

    def get_context_data(self, **kwargs):
        context = super(AllAuthorsView, self).get_context_data(**kwargs)
        context['a'] = Author.objects.filter(full_name__startswith="A")
        context['b'] = Author.objects.filter(full_name__startswith="B")
        context['c'] = Author.objects.filter(full_name__startswith="C")
        context['d'] = Author.objects.filter(full_name__startswith="D")
        context['e'] = Author.objects.filter(full_name__startswith="E")
        context['f'] = Author.objects.filter(full_name__startswith="F")
        context['g'] = Author.objects.filter(full_name__startswith="G")
        context['h'] = Author.objects.filter(full_name__startswith="H")
        context['i'] = Author.objects.filter(full_name__startswith="I")
        context['j'] = Author.objects.filter(full_name__startswith="J")
        context['k'] = Author.objects.filter(full_name__startswith="K")
        context['l'] = Author.objects.filter(full_name__startswith="L")
        context['m'] = Author.objects.filter(full_name__startswith="M")
        context['n'] = Author.objects.filter(full_name__startswith="N")
        context['o'] = Author.objects.filter(full_name__startswith="O")
        context['p'] = Author.objects.filter(full_name__startswith="P")
        context['q'] = Author.objects.filter(full_name__startswith="Q")
        context['r'] = Author.objects.filter(full_name__startswith="R")
        context['s'] = Author.objects.filter(full_name__startswith="S")
        context['t'] = Author.objects.filter(full_name__startswith="T")
        context['u'] = Author.objects.filter(full_name__startswith="U")
        context['v'] = Author.objects.filter(full_name__startswith="V")
        context['w'] = Author.objects.filter(full_name__startswith="W")
        context['x'] = Author.objects.filter(full_name__startswith="X")
        context['y'] = Author.objects.filter(full_name__startswith="Y")
        context['z'] = Author.objects.filter(full_name__startswith="Z")
        return context


class BookListView(generic.ListView):
    template_name = 'book_list.html'
    model = Book

    def get_queryset(self):
        order = self.request.GET.get("sort")
        order2 = self.request.GET.get("order")
        queryset_list = Book.objects.all()

        query = self.request.GET.get("q")  # this gets the contents from the search bar 'q'
        if query:
            if query in 'Tech Valley Times Best Sellers':
                queryset_list = queryset_list.filter(tech_valley_best=1)
            elif query in 'Coming Soon':
                queryset_list = queryset_list.filter(publication_date__gt=datetime.date.today())
            elif 'Star' in query:
                if 'One' in query:
                    queryset_list = queryset_list.filter(avg_rating__range=(1, 1.9))
                elif 'Two' in query:
                    queryset_list = queryset_list.filter(avg_rating__range=(2, 2.9))
                elif 'Three' in query:
                    queryset_list = queryset_list.filter(avg_rating__range=(3, 3.9))
                elif 'Four' in query:
                    queryset_list = queryset_list.filter(avg_rating__range=(4, 4.5))
                elif 'Five' in query:
                    queryset_list = queryset_list.filter(avg_rating__range=(4.6, 5))

            else:
                queryset_list = queryset_list.filter(title__icontains=query).distinct() | \
                                queryset_list.filter(authors__full_name__icontains=query).distinct() | \
                                queryset_list.filter(genre__icontains=query).distinct()

        if order:
            order = order.strip()
            if query and order2 and queryset_list.filter(genre__icontains=query):
                queryset_list = queryset_list.order_by(order, order2)
            else:
                if order == 'sales_rank':
                    queryset_list = queryset_list.order_by(order).exclude(sales_rank=0)
                else:
                    queryset_list = queryset_list.order_by(order)
        else:
            if query and order2 and queryset_list.filter(genre__icontains=query):
                queryset_list = queryset_list.order_by("-tech_valley_best", order2)
            else:
                queryset_list = queryset_list.order_by("title")

        return queryset_list

    def get_context_data(self, **kwargs):
        context = super(BookListView, self).get_context_data(**kwargs)
        queryset_list = self.get_queryset()
        display_sort = self.request.GET.get("display")
        order = self.request.GET.get("sort")
        order2 = self.request.GET.get("order")
       
        
        context['total'] = self.get_queryset().count()
        query = self.request.GET.get("q")

        if query:
            context['q'] = query

        if order:
            context['sort'] = order
            if order == 'title':
                context['sorting'] = "Title - A to Z"
            elif order == '-title':
                context['sorting'] = "Title - Z to A"
            elif order == '-avg_rating':
                context['sorting'] = "Top Rated"
            elif order == 'publication_date':
                context['sorting'] = "Oldest"
            elif order == '-publication_date':
                context['sorting'] = "Newest"
            elif order == 'authors':
                context['sorting'] = "Author(s) A - Z"
            elif order == '-authors':
                context['sorting'] = "Author(s) Z - A"
            elif order == 'price':
                context['sorting'] = "Price - Low to High"
            elif order == '-price':
                context['sorting'] = "Price - High to Low"
            elif order == 'sales_rank':
                context['sorting'] = "Top Sellers"
            elif order == '-tech_valley_best':
                context['sorting'] = "Tech Valley Best Sellers"
        else:
            if query and Book.objects.filter(genre__icontains=query):
                context['sort'] = "-tech_valley_best"
                context['order'] = "-rating"
                context['sorting'] = "Tech Valley Best Sellers"
            else:
                context['sort'] = "title"
                context['sorting'] = "Title - A to Z"

        if display_sort:
            if queryset_list.count() > int(display_sort):
                context['display_sort_num'] = display_sort
            else:
                context['display_sort_num'] = display_sort
        else:
            if queryset_list.count() > 10:
                context['display_sort_num'] = 10
            else:
                context['display_sort_num'] = 10

        if order2:
            context['order'] = order2

        return context

    def get_paginate_by(self, queryset):
        display_sort = self.request.GET.get("display")
        if display_sort:
            if queryset.count() > int(display_sort):
                paginate_by = display_sort
            else:
                paginate_by = queryset.count()
        else:
            if queryset.count() > 10:
                paginate_by = 10
            else:
                paginate_by = queryset.count()

        return paginate_by


class BookDetailView(generic.DetailView):
    template_name = 'book_detail.html'
    model = Book

    def get_context_data(self, **kwargs):
        context = super(BookDetailView, self).get_context_data(**kwargs)
        number = cart_count(self.request)
        context['number'] = number
        author = Author.objects.filter(book=self.kwargs.get("pk")).distinct()
        context['author_books'] = Book.objects.filter(authors__book__authors__in=author).distinct().exclude(
        pk=self.kwargs.get("pk"))
        return context